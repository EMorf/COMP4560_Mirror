#include <stdio.h>
void encode(char* sequence, unsigned int window, unsigned int buffer, int single_row, FILE* file);
#include "LZ77_decode.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include "getopt.h"
#pragma warning(disable:4996)
#else 
#include <unistd.h>
#include <string.h>
#endif

// [i]nput file, [o]utput file.
#define OPT_STR "i:o:" 

// Main function for serial decoder. Handles file I/O.
int main(int argc, char* argv[]) {

	// Handle command line arguements
	char c;
	char *in_file = "encoded.txt";
	char *out_file = "decoded.txt";

	while ((c = getopt(argc, argv, OPT_STR)) != EOF) {
		switch (c) {
		case 'i': in_file = optarg;
			break;
		case 'o': out_file = optarg;
			break;
		default: printf("Usage : %s -i input_file -o output_file\n", argv[0]);
			return EXIT_FAILURE;
		}
	}
	// End of handling arguements

	// Input file opening
	FILE *fp;
	if ((fp = fopen(in_file, "rb")) == NULL) {
		printf("Could not find input file %s. Aborting...\n", in_file);
		return EXIT_FAILURE;
	}

	// Output file opening/creation
	FILE *fw;
	if ((fw = fopen(out_file, "wb")) == NULL) {
		printf("File writing error. Aborting...\n");
		return EXIT_FAILURE;
	}
	
	// Copy and paste file input to a string
	if (fseek(fp, 0, SEEK_END) != 0) {
		printf("Corrupted file. Aborting...\n");
		return EXIT_FAILURE;
	}
	size_t fsize = ftell(fp);

	if (fseek(fp, 0, SEEK_SET) != 0) {
		printf("Corrupted file. Aborting...\n");
		return EXIT_FAILURE;
	}
	char *input = malloc(fsize + 1);
	if (input == NULL) {
		printf("Cannot allocate enough memory. Aborting...\n");
		return EXIT_FAILURE;
	}

	// Copy input file contents to a string in memory and close the file pointer
	fread(input, fsize, 1, fp);
	input[fsize] = 0;
	fclose(fp);
	
	char *output;
	if ((output = malloc(fsize)) == NULL) {
		free(input);
		fclose(fw);
		printf("\nCannot allocate memory, aborting...\n");
		return EXIT_FAILURE;
	}
	// Main decoding operation, complete it 
	// and check for errors
	if (decode(input, output) != 0) {
		free(input);
		free(output);
		fclose(fw);
		printf("\nMalformed input, aborting...\n");
		return EXIT_FAILURE;
	}
	free(input);

	// Copy decoded string to output and free the other resources
	if (strlen(output) == 0) {
		printf("\nWarning: Output is empty. Ensure that the input file contains a properly encoded sequence.\n");
		free(output);
		fclose(fw);
		return EXIT_FAILURE;
	}
	fputs(output, fw);
	free(output);
	fclose(fw);
	printf("File name is %s\n", out_file);
	return EXIT_SUCCESS;
	
}
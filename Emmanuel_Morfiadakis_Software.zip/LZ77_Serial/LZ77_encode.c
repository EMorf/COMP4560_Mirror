#include "LZ77_encode.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32 
#pragma warning(disable:4996)
#endif

#define SLIDING_WINDOW 16
#define BUFFER 16

/**
* Converts a string to its LZ77 reprensetation. This article outlines the algorithm
* and was used as the basis of the code below: https://msdn.microsoft.com/en-us/library/ee916854.aspx
* @param sequence the input string that will be converted
* @param window size of the sliding window, defaults to 16 if it is not specified by the user
* @param buffer size of the lookahead buffer, also defaults to 16.
* @param single_row if set to 1, the encoded text is outputted in a single line, if set to 0 text is in a single column
* @return void result is printed directly to the file
*/
void encode(char* sequence, unsigned int window, unsigned int buffer, int single_row, FILE* file) {
	if (window <= 0) {
		window = SLIDING_WINDOW;
	}
	if (buffer <= 0) {
		buffer = BUFFER;
	}

	unsigned int pointer = 0;
	unsigned int i = 0;

	/* Growing sliding window phase, this means that the sliding window is not full yet and is partially populated*/
	while(i < window && i < strlen(sequence)) {
		unsigned int max_length = 0;
		int offset = 0;
		for (unsigned int j = 0; j < i; j++) {
			unsigned int cnt = 0;
			// Match the current lookahead buffer contents with the ones in the sliding window
			if (sequence[j] == sequence[i]) {
				while (sequence[j + cnt] == sequence[i + cnt] && cnt < buffer ) {
					cnt++;
				}
				if (cnt >= max_length) {
					max_length = cnt;
					offset = i - j;
				}
			}
		}
		// Case where nothing is matched so we output a literal tuple
		if (offset == 0 && max_length == 0) {
			// Since some characters can corrupt the formatting of the output file,
			// we store them as special symbols
			if (sequence[i] == '\n') {
				fprintf(file, "(0, 0, \\n)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[i] == '\r') {
				fprintf(file, "(0, 0, \\r)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[i] == '(') {
				fprintf(file, "(0, 0, po)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[i] == ')') {
				fprintf(file, "(0, 0, pc)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[i] == '\t') {
				fprintf(file, "(0, 0, \\t)%s", (single_row ? "" : "\n"));
			}
			else {
				fprintf(file, "(0, 0, %c)%s", sequence[i], (single_row ? "" : "\n"));
			}
			i++;
			
		}
		// Case where a sequence is matched so we output a backreference tuple
		else {
			fprintf(file, "(%d, %d)%s", offset, max_length, (single_row ? "" : "\n"));
			i += max_length;
		}
		pointer = i;
	}

	/* Fixed window size phase, operation is as above with the exception of adjusting some indices */
	while (pointer < strlen(sequence)) {
		if(pointer % 10000 == 0 && strlen(sequence) > 10000)
		printf("Done: %f percent\r", (float)(pointer) * 100 / (float)strlen(sequence));

		int max_len = 0;
		int offset = 0;
		for (unsigned int i = pointer - window; i < pointer; i++) {
			if (sequence[i] == sequence[pointer]) {
				int length = 1;
				unsigned int j = 1;
				while (sequence[i + j] == sequence[pointer + j] && j < buffer) {
					length++;
					j++;
				}
				if (length >= max_len) {
					max_len = length;
					offset = pointer - i;
				}
			}

			
		}
		// Again, special characters are converted
		if (max_len == 0) {
			if (sequence[pointer] == '\n') {
				fprintf(file, "(0, 0, \\n)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[pointer] == '\r') {
				fprintf(file, "(0, 0, \\r)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[pointer] == '(') {
				fprintf(file, "(0, 0, po)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[pointer] == ')') {
				fprintf(file, "(0, 0, pc)%s", (single_row ? "" : "\n"));
			}
			else if (sequence[pointer] == '\t') {
				fprintf(file, "(0, 0, \\t)%s", (single_row ? "" : "\n"));
			}
			else {
				fprintf(file, "(0, 0, %c)%s", sequence[pointer], (single_row ? "" : "\n"));
			}
		}
		else {
			fprintf(file, "(%d, %d)%s", offset, max_len, (single_row ? "" : "\n"));
		}
		// Increment the pointer based on how many previous characters where matched
		pointer = pointer + (max_len == 0 ? 1 : max_len);
	}

	return;
}
#include <stdio.h>
#include <stdlib.h>
#include "LZ77_encode.h"
#ifdef _WIN32
#include "getopt.h"
#pragma warning(disable:4996)
#else 
#include <unistd.h>
#endif

//[f]ile name, [i]nput string, [w]indow size, [b]uffer size, single [r]ow output
#define OPT_STR "f:i:w:b:o:r" 

// Main function of serial encoder. Handles file I/O.
int main(int argc, char* argv[]) {

	// Handle command line arguements
	char c;   
	char *file = "stream.txt";
	char *file_out = "encoded.txt";
	char *input = "abc123";  
	int window = 0;
	int buffer = 0;
	int file_override = 0;
	int row = 0;

	while ((c = getopt(argc, argv, OPT_STR)) != EOF) {
		switch (c) { 
		case 'f': file = optarg;     
			file_override = 1;
			break;         
		case 'i': input = optarg;     
			break;    
		case 'o': file_out = optarg;
			break;
		case 'w': window = atoi(optarg);     
			break;     
		case 'b': buffer = atoi(optarg);
			break;
		case 'r': 
			row = 1;
			break;
		default: printf("Usage : %s -f input_filename | -i string -o output_filename [-w number] [-b number] [-r]\n", argv[0]);
			return EXIT_FAILURE; }
	}
	// end of CMD line arguement checks

	FILE *fw;
	if ((fw = fopen(file_out, "w")) == NULL) {
		printf("File writing error. Aborting...\n");
		return EXIT_FAILURE;
	}
	// Case where user requests input to be read from a file
	if (file_override) {
		// Read input file
		FILE *fp;
		if ((fp = fopen(file, "rb")) == NULL) {
			printf("File reading error. Aborting...\n");
			return EXIT_FAILURE;
		}

		// Read the input file size and copy it to a string
		fseek(fp, 0, SEEK_END);
		size_t fsize = ftell(fp);
		fseek(fp, 0, SEEK_SET);  
		char *string = malloc(fsize + 1);

		// Handle memory allocation errors
		if (string == NULL) {
			printf("Unable to assign enough memory. Aborting...\n");
			free(string);
			fclose(fp);
			return EXIT_FAILURE;
		}

		fread(string, fsize, 1, fp);
		string[fsize] = 0;

		// File is copied to string so we can close it
		if (fclose(fp) != 0) {
			printf("Unable to close file input. Aborting...\n");
			free(string);
			return EXIT_FAILURE;
		}

		encode(string, window, buffer, row, fw);
		free(string);
		printf("\n All done! File name is %s\n", file_out);
		return EXIT_SUCCESS;

	}

	// Case where input is read as a command line arguement
	else {
		encode(input, window, buffer, row, fw);
	}
	printf("\n All done! File name is %s\n", file_out);
	fclose(fw);
	return EXIT_SUCCESS;
}
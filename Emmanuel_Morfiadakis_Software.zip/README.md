# Parallel GPU LZ77 Decoding

This repository contains all the source files that are used to generate the serial and parallel implementations of the LZ77 decoding program. There are two sub-projects, namely **LZ77 Parallel** (in CUDA) and **LZ77_Serial** (in C) that contain all the required code. A helper utility which generates encoded LZ77 sequences from any text file is also present in the LZ77_Serial folder, and was used to generate test data for the other two utilities. It is recommended that you open the project by cloning the repo and running the file **LZ77.sln**  in **Microsoft Visual Studio 2015** (or newer). Makefiles are also provided for compiling and running on **Unix** or **MacOS**.

## Source code structure

### Serial Decoder
This program accepts an **LZ77 encoded text string or file** (containing Latin characters, numbers and symbols) and **decodes it serially**, on the CPU. The main function is located in **_LZ77_Serial/decoder.c_** and is used for I/O operations, such as reading from the input file and writing the output file. The decoding procedure is implemented as a single function contained in the LZ77_decode module, which consists the header file **_LZ77_decode.h_** and the implementation file **_LZ77_decode.c_**.

### Parallel Decoder
This program accepts an **LZ77 encoded text string or file** (containing Latin characters, numbers and symbols) and decodes it in parallel, on the GPU. The main function is located in **_LZ77 Serial/decoder.cu and_** is used for I/O operations, such as reading from the input file and writing the output file. The decoding procedure is implemented as a single function contained in the LZ77_decode module, which consists the header file **_LZ77_decode.cuh_** and the implementation file **_LZ77_decode.cu_**.

### Serial Encoder
This program accepts a **sequence of text** and encodes it serially, on the CPU. The main function is located in **_LZ77_Serial/encoder.c_** and is used for I/O operations, such as reading from the input file and writing the output file. The encoding procedure is implemented as a single function contained in the LZ77_encode module, which consists of the header file **_LZ77_encode.h_** and the implementation file **_LZ77_encode.c_**.

## Installation

Both ```gcc``` and ```nvcc``` are required to compile the source files. Also, due to the use of unified memory, only **64-bit** systems running ```nvcc 6.0``` or later will be able to execute the parallel decoder program.

#### Windows
Import the project in **Microsoft Visual Studio**, and set the build version to **Release and 64 bits** by using the dropdown menus. Ensure that the project you want to compile is loaded in the Solution Explorer menu (**LZ77 Parallel** or **LZ77_Serial**) and unload the other one by right-clicking it and selecting Unload Project.  Then, click Local Windows Debugger to generate the .exe file. Given that two main files are specified (decoder.c and encoder.c) in the serial implementation, you should **exclude** one or the other from the project, depending on which program you want to compile.

#### Unix
Use the supplied Makefiles to compile and link. Appropriate commands include:
``` 
make all
make p_decoder
make s_encoder
make s_decoder
make clean
```

#### MacOS
The same as Unix, but instead of 
``` 
make s_decoder
```
use 

```
make s_decoder_mac
```

The timing library has been removed, as there is no reliable timekeeping function on MacOS.
## Usage
#### Serial Encoder:

```
s_encoder -f file_name | -i input_string [-o output_file] [-w window_size] [-b buffer_size] [-r]
```

**_-f_** specifies the name of text file that will be encoded. It must be placed in the same directory as the program binary. Alternatively, **-i** can be used to directly specify an input string through the command line. Exactly one of these options must be provided during invocation of the program.

**_-o_** provides the name of the text file that will contain the encoded sequence, once the program completes execution.

**_-w_** is used to specify the LZ77 Sliding Window size, and must be a positive number. Similarly, **_-b_** specifies the lookahead buffer size. Both of these values are initialised to **16**.

Finally, using the option **_-r_** will force the output to be printed on a single line. Not specifying this option will seperate each encoded tuple with a newline.

#### Serial Decoder:

```
s_decoder -i input_file -o output_file
```
**_-i_** determines the name of the encoded text file that will be decoded.
**_-o_** determines the name of the file that will contain the decoded text sequence.
#### Parallel Decoder:

```
p_decoder -i input_file -o output_file
```
Exactly the same as s_decoder.


## Data sets

8 different data sets of various sizes are located in the **_"Encoded Test Data"_** folder and can be used to test the operation of the provided decoders.

##### Example: Compressing and decompressing the Paper data set
0) Ensure all three programs are compiled and stored in the same directory

1) Copy the file Paper.txt to that directory

2) Invoke the compression program with the command ``` s_encoder -f Paper.txt -o PaperEncoded.txt -r```

3) Invoke the serial decompression program with the command ```s_decoder -f PaperEncoded.txt -o PaperDecodedSerial.txt```

4) Invoke the parallel decompression program with the command ```p_decoder -f PaperEncoded.txt -o PaperDecodedParallel.txt```

5) Inspect the files ```Paper.txt```,``` PaperDecodedSerial.txt```, ```PaperDecodedParallel.txt``` and confirm they have the same content.


## Acknowledgements 
Acknowledgements of third party software are placed in the **_Originality.txt_** files in each sub-project directory.
